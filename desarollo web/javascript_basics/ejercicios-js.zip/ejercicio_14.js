function esPotenciaDeDos(numero) {
  return (numero & (numero - 1)) === 0 && numero !== 0;
}

// Pruebas
console.log(esPotenciaDeDos(16));  // Esperado: true
console.log(esPotenciaDeDos(64));  // Esperado: true
console.log(esPotenciaDeDos(12));  // Esperado: false
console.log(esPotenciaDeDos(0));   // Esperado: false
