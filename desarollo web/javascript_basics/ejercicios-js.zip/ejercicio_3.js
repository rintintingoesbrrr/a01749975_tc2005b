// Función que devuelve un nuevo arreglo invertido
function invertirArregloNuevo(arreglo) {
    return arreglo.slice().reverse();
}

// Función que modifica el arreglo original
function invertirArregloModificado(arreglo) {
    let inicio = 0;
    let fin = arreglo.length - 1;
    while (inicio < fin) {
        // Swap
        let temp = arreglo[inicio];
        arreglo[inicio] = arreglo[fin];
        arreglo[fin] = temp;
        inicio++;
        fin--;
    }
    return arreglo;
}

// Pruebas
let arregloOriginal = [1, 2, 3, 4, 5];
console.log(invertirArregloNuevo(arregloOriginal));      // Esperado: [5, 4, 3, 2, 1]
console.log(invertirArregloModificado(arregloOriginal)); // Esperado: [5, 4, 3, 2, 1]
console.log(invertirArregloNuevo([9, 7, 5, 3, 1]));     // Esperado: [1, 3, 5, 7, 9]
console.log(invertirArregloModificado([9, 7, 5, 3, 1])); // Esperado: [1, 3, 5, 7, 9]


