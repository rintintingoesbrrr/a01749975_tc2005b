function primerCaracterNoRepetido(cadena) {
  let frecuencia = {};

  // Contar la frecuencia de cada carácter
  for (let caracter of cadena) {
      frecuencia[caracter] = (frecuencia[caracter] || 0) + 1;
  }

  // Encontrar el primer carácter no repetido
  for (let caracter of cadena) {
      if (frecuencia[caracter] === 1) {
          return caracter;
      }
  }

  // Si no se encuentra ningún carácter no repetido, retornamos null
  return null;
}

// Pruebas
console.log(primerCaracterNoRepetido('abacddbec')); // Esperado: 'e'
console.log(primerCaracterNoRepetido('aabbcc'));    // Esperado: null
console.log(primerCaracterNoRepetido('aabbc'));     // Esperado: 'c'
