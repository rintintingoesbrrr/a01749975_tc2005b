function bubbleSort(lista) {
  let n = lista.length;
  for (let i = 0; i < n-1; i++) {
      for (let j = 0; j < n-i-1; j++) {
          if (lista[j] > lista[j+1]) {
              // Swap
              let temp = lista[j];
              lista[j] = lista[j+1];
              lista[j+1] = temp;
          }
      }
  }
  return lista;
}

// Pruebas
console.log(bubbleSort([5, 3, 8, 1, 2])); // Esperado: [1, 2, 3, 5, 8]
console.log(bubbleSort([9, 7, 6, 5, 4])); // Esperado: [4, 5, 6, 7, 9]
console.log(bubbleSort([9, 8, 7, 6, 5])); // Esperado: [5, 6, 7, 8, 9]
