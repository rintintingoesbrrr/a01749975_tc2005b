function esPalindromo(cadena) {
  // Eliminamos los caracteres no alfabéticos y convertimos la cadena a minúsculas
  cadena = cadena.toLowerCase().replace(/[^a-z]/g, '');
  // Comparamos la cadena original con su versión invertida
  return cadena === cadena.split('').reverse().join('');
}

// Pruebas
console.log(esPalindromo('anita lava la tina')); // Esperado: true
console.log(esPalindromo('oso'));               // Esperado: true
console.log(esPalindromo('hola mundo'));        // Esperado: false
