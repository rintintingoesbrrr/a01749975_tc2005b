function hackerSpeak(cadena) {
  return cadena.replace(/[aeio]/gi, function(char) {
      switch (char.toLowerCase()) {
          case 'a': return '4';
          case 'e': return '3';
          case 'i': return '1';
          case 'o': return '0';
      }
  });
}

// Pruebas
console.log(hackerSpeak('Javascript es divertido')); // Esperado: 'J4v45cr1pt 3s d1v3rt1d0'
console.log(hackerSpeak('Hola mundo'));             // Esperado: 'H0l4 mund0'
console.log(hackerSpeak('Programación'));           // Esperado: 'Pr0gr4m4c10n'
