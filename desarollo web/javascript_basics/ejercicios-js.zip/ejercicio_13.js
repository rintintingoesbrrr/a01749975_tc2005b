function cadenaMasFrecuente(lista) {
  let frecuencia = {};
  for (let cadena of lista) {
      frecuencia[cadena] = (frecuencia[cadena] || 0) + 1;
  }
  let maxFrecuencia = 0;
  let cadenaMasFrecuente = null;
  for (let cadena in frecuencia) {
      if (frecuencia[cadena] > maxFrecuencia) {
          maxFrecuencia = frecuencia[cadena];
          cadenaMasFrecuente = cadena;
      }
  }
  return cadenaMasFrecuente;
}

// Pruebas
console.log(cadenaMasFrecuente(['hola', 'mundo', 'hola', 'javascript', 'mundo'])); // Esperado: 'hola'
console.log(cadenaMasFrecuente(['perro', 'gato', 'perro', 'gato', 'gato']));        // Esperado: 'gato'
console.log(cadenaMasFrecuente(['manzana', 'pera', 'uva', 'manzana']));              // Esperado: 'manzana'
