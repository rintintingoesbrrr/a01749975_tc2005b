function factoriza(numero) {
  let factores = [];
  for (let i = 1; i <= numero; i++) {
      if (numero % i === 0) {
          factores.push(i);
      }
  }
  return factores;
}

// Pruebas
console.log(factoriza(12)); // Esperado: [1, 2, 3, 4, 6, 12]
console.log(factoriza(20)); // Esperado: [1, 2, 4, 5, 10, 20]
console.log(factoriza(7));  // Esperado: [1, 7]
