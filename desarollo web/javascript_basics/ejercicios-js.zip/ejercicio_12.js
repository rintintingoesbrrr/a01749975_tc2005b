function calcularMedianaYModa(lista) {
  let sortedList = lista.slice().sort((a, b) => a - b);
  let n = sortedList.length;
  let mediana = n % 2 === 0 ? (sortedList[n / 2 - 1] + sortedList[n / 2]) / 2 : sortedList[Math.floor(n / 2)];

  let moda = null;
  let maxFrecuencia = 0;
  let frecuencia = {};
  for (let num of sortedList) {
      frecuencia[num] = (frecuencia[num] || 0) + 1;
      if (frecuencia[num] > maxFrecuencia) {
          moda = num;
          maxFrecuencia = frecuencia[num];
      }
  }

  return { mediana, moda };
}

// Pruebas
console.log(calcularMedianaYModa([1, 2, 3, 4, 5]));          // Esperado: { mediana: 3, moda: null }
console.log(calcularMedianaYModa([1, 2, 3, 4, 5, 5, 5]));    // Esperado: { mediana: 4, moda: 5 }
console.log(calcularMedianaYModa([5, 3, 1, 7, 9, 7, 3, 5])); // Esperado: { mediana: 5, moda: 5 }
