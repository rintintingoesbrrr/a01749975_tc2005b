function ordenDescendente(lista) {
  return lista.slice().sort((a, b) => b - a);
}

// Pruebas
console.log(ordenDescendente([5, 2, 7, 1, 9]));     // Esperado: [9, 7, 5, 2, 1]
console.log(ordenDescendente([18, 27, 36, 9]));    // Esperado: [36, 27, 18, 9]
console.log(ordenDescendente([10, 8, 12, 6, 15])); // Esperado: [15, 12, 10, 8, 6]
