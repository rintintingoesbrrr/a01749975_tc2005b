function maximoComunDivisor(a, b) {
  while (b !== 0) {
      let temp = b;
      b = a % b;
      a = temp;
  }
  return Math.abs(a); // Tomamos el valor absoluto para garantizar que el resultado sea siempre positivo
}

// Pruebas
console.log(maximoComunDivisor(24, 36));  // Esperado: 12
console.log(maximoComunDivisor(18, 27));  // Esperado: 9
console.log(maximoComunDivisor(17, 5));   // Esperado: 1
