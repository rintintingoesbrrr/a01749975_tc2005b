function ordenAlfabetico(lista) {
  return lista.slice().sort();
}

// Pruebas
console.log(ordenAlfabetico(['perro', 'gato', 'elefante'])); // Esperado: ['elefante', 'gato', 'perro']
console.log(ordenAlfabetico(['banana', 'manzana', 'uva'])); // Esperado: ['banana', 'manzana', 'uva']
console.log(ordenAlfabetico(['javascript', 'python', 'java'])); // Esperado: ['java', 'javascript', 'python']
