function longitudCadenaMasCorta(lista) {
  let longitudMinima = Infinity;
  for (let cadena of lista) {
      longitudMinima = Math.min(longitudMinima, cadena.length);
  }
  return longitudMinima;
}

// Pruebas
console.log(longitudCadenaMasCorta(['hola', 'mundo', 'es'])); // Esperado: 2
console.log(longitudCadenaMasCorta(['javascript', 'es', 'genial'])); // Esperado: 2
console.log(longitudCadenaMasCorta(['a', 'bb', 'ccc'])); // Esperado: 1
