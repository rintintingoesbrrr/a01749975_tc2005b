function quitaDuplicados(arreglo) {
  return arreglo.filter((valor, indice) => arreglo.indexOf(valor) === indice);
}

// Pruebas
console.log(quitaDuplicados([1, 0, 1, 1, 0, 0])); // Esperado: [1, 0]
console.log(quitaDuplicados([5, 3, 2, 3, 5]));   // Esperado: [5, 3, 2]
console.log(quitaDuplicados(['a', 'b', 'a']));  // Esperado: ['a', 'b']
