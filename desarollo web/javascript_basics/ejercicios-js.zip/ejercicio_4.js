function capitalizarPrimerasLetras(cadena) {
  return cadena.replace(/\b\w/g, function(char) {
      return char.toUpperCase();
  });
}

// Pruebas
console.log(capitalizarPrimerasLetras('hola mundo'));        // Esperado: 'Hola Mundo'
console.log(capitalizarPrimerasLetras('javascript es genial')); // Esperado: 'Javascript Es Genial'
console.log(capitalizarPrimerasLetras('hoy es un buen día')); // Esperado: 'Hoy Es Un Buen Día'
